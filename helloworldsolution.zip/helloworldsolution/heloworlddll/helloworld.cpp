#include "stdafx.h"
#include "helloworld.h"



helloworld::helloworld()
{
}


helloworld::~helloworld()
{
}
void helloworld::greet() {
	cout << "hello " << endl;
	
}
