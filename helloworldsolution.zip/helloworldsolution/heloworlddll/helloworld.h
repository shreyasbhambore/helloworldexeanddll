#pragma once
#ifdef HELOWORLDDLL_EXPORTS
#define EXIM __declspec(dllexport)
#else
#define EXIM __declspec(dllimport)


#endif // 

#include<iostream>
using namespace std;
class EXIM helloworld
{
public:
	helloworld();
	~helloworld();
	void greet();
};

