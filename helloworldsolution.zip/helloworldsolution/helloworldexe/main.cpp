#include"stdafx.h"
#include"../heloworlddll/helloworld.h"
using namespace std;
int main() {
	helloworld *h1 = new helloworld();
	h1->greet();
	int i;
	cin >> i;
	cout << i << endl;
	
	return 0;
}